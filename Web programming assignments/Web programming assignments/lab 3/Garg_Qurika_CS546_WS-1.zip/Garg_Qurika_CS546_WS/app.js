const todoItems = require("./todo");
const connection = require("./mongoConnection");

//1.
let firstcreatedTask = todoItems.createTask("Ponder Dinosaurs", "Has Anyone Really Been Far Even as Decided to Use Even Go Want to do Look More Like?");

//2.
let dispalyingFirst = firstcreatedTask.then((task) => {  
    console.log("one task has been added");
    console.log(task);
    return task;
});

let secondCreatedTask=dispalyingFirst.then((task)=>{
    console.log("Next task has been added")
   return todoItems.createTask("Play Pokemon with Twitch TV", "Should we revive Helix?");
    
});


//3
let allTasksQuery=secondCreatedTask.then(()=>{
    console.log("All tasks are getting fetched");
    return todoItems.getAllTasks();
});

let printAllTasks=allTasksQuery.then((tasks)=>{
    console.log(tasks);
    return tasks;
});


//4

let firstRemoveTask=printAllTasks.then((tasks)=>{
    console.log("First task is getting removed: ");
    return todoItems.removeTask(tasks[0]._id);
  

});

//5

let allTasksQuery2= firstRemoveTask.then(()=>{
    console.log("All tasks are getting fetched after removal of first task");
    return todoItems.getAllTasks();
});

let printAllTasks2= allTasksQuery2.then((tasks)=>{
        console.log(tasks);
        return tasks;
});

//6

let remainingTasksComplete=printAllTasks2.then((task)=>{
    console.log("Remaining tasks are getting completed");
    for(let i=0;i<task.length;i++){
         todoItems.completeTask(task[i]._id);
    }
    return;
});


//7

let allTasksQuery3= remainingTasksComplete.then(()=>{
console.log("Fetching all remaining completed tasks");
return todoItems.getAllTasks();
});

let printAllTaks3=allTasksQuery3.then((tasks)=>{
    console.log(tasks);
    return tasks;
});

let errorFinder=printAllTaks3.catch((error)=>{
    console.log(error);
    return error;
})
.catch().then(()=>{
    return connection();
})
.then((db)=>{
    return db.close();
});
