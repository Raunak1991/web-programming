const mongoCollections = require("./mongoCollections");
const todoItems = mongoCollections.todoItems;
var mongo = require('mongodb');
//var ObjectId = require('mongodb').ObjectID;
var uuid = require('node-uuid')

let exportedMethods = {
    getTask(id) {
        if(!id){
            return Promise.reject("Please provide task id to search")
        }
        return todoItems().then((itemCollection) => {
        let found=itemCollection.findOne({_id:id});
       return found.then((data)=>{
           if(data==null)
           return Promise.reject("Task with provided id cannot be found")
           else
           return data;

       });
        });
    },


    createTask(title, description) {
        if(!title || !description){
        return Promise.reject("Please provide title and decription");
        }
        return todoItems().then((itemCollection) => {
            
            let newItem = {
                _id:uuid.v4(),
                title: title,
                description: description,
                completed: false,
                completedAt: null
            };
            return itemCollection.insertOne(newItem).then((newInsertInformation) => {
                if(newInsertInformation==null){
                    return Promise.reject("Cannot create a task")
                }
                return newInsertInformation.insertedId;
            }).then((newId) => {
                return this.getTask(newId);
            });
        });
    },
    getAllTasks() {
       return todoItems().then((data)=>{
        return data.find().toArray();
    });
    },
    completeTask(taskId) {
        if(!taskId){
            return Promise.reject("Please provide task id")
        }
        return todoItems().then((itemCollection) => {
            let tm = new Date(new Date().getTime()).toLocaleTimeString();
            return itemCollection.updateOne({ _id: taskId }, { $set: { completed: true, completedAt: tm } }).then(() => {
                return this.getTask(taskId);
            },(error)=>{
                Promise.reject("Task cannot be updated")
            });

        });
    },

    removeTask(id) {
         if(!id){
            return Promise.reject("Please provide task id")
        }
        return todoItems().then((itemCollection) => {
            return itemCollection.removeOne({ _id: id }).then((deletionInfo) => {
                  if (deletionInfo.deletedCount === 0) {
                    throw (`Could not delete task with id of ${id}`);
                }

                return deletionInfo;

            });
        });


    }
};

module.exports = exportedMethods;