const classesData=require("./classes");
const educationData=require("./education");
const hobbiesData=require("./hobbies");


module.exports={
classes:classesData,
education:educationData,
hobbies:hobbiesData,
 };